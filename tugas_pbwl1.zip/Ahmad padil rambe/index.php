<?php 

require_once "inc/config.php";

new App\Core\Bootstrap();